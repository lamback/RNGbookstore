create function f2(num1 smallint(5) unsigned, num2 smallint(5) unsigned)
  returns float(10, 2) unsigned
  return (num1+num2)/2;

